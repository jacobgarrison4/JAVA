
public interface Measurable 
{
	double getArea(); //Calculate area
}
